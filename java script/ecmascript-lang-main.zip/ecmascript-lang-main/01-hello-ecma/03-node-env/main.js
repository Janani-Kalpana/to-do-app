// window.alert("Hello ECMAScript!");
console.log("Hello ECMAScript!");