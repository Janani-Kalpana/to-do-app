console.log("Hello");
console.log(myVar);
//console.log(myLet);
var myVar = 10;
let myLet = 20;
console.log(myVar);
console.log(myLet);
{
    // console.log(myLet);
    var myVar2 = "abc";
    let myLet = "ESOFT";
    console.log(myLet);
}
console.log(myVar2);
console.log(myLet);