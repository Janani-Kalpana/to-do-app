console.log("Module3");

let x = 30;
let y = 40;
let z = 50;

export { x, y };    // named exports
export default z;   // only one default export per module