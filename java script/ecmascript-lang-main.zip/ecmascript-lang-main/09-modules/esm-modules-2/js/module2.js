import './module3.js';

console.log("Module2");
export let x = 20;