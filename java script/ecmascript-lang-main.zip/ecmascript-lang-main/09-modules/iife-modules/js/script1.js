(function(){
    console.log("Script1");
    const something = "Module";
})();
