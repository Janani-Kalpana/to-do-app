(function () {
    console.log("Script2");
    const crazy = "!";
})();