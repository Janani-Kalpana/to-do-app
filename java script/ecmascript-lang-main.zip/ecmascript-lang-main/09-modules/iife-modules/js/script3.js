(function () {
    console.log("Script3");

    function handleButtonClick() {
        alert("Clicked! " + `${name} ${something} ${crazy}`);
    }
})();