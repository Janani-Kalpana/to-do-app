console.log("Module2", myGlobal, myGlobal2);
let x = 20;