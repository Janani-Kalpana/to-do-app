console.log("Script");
const myGlobal = "I am from the global env";